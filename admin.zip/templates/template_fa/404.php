
<!-- separator -->
<div class="row xxxsmallSpace"></div>

<!-- boxContainer -->
<div class="boxContainer registerPage notFoundPage center-block whiteBg boxBorder roundCorner">
    <div class="content">

        <!-- separator -->
        <div class="row xxxsmallSpace"></div>

        <img style="max-width: 300px; margin-top:  3em;" class="center-block" src="<?php echo '/templates/'.CURRENT_SKIN; ?>/assets/img/notFoundImg.png" alt="صفحه مورد نظر یافت نشد">
        <h3 class="text-center text-dark">۴۰۴</h3>
        <h4 class="text-center text-dark">صفحه مورد نظر یافت نشد</h4>

        <!-- separator -->
        <div class="row xsmallSpace"></div>


    </div>
</div>
<!-- /end of boxContainer -->