
</section>

<!-- footer of website -->
<footer id="home" class="clearfix">
    <p dir="ltr">© 2019 </p>
    <ul>
        <li><a href="#0" class="animated_link"><i class="fa fa-home"></i>صفحه اصلی</a></li>
        <li><a href="#0" class="animated_link"><i class="fa fa-phone-square"></i>تماس با ما </a></li>
    </ul>
</footer>
<!-- end footer-->


<div class="cd-overlay-nav">
    <span></span>
</div>
<!-- cd-overlay-nav -->

<div class="cd-overlay-content">
    <span></span>
</div>
<!-- cd-overlay-content -->

<a href="#0" class="cd-nav-trigger" >فهرست<span class="cd-icon"></span></a>

<!-- SCRIPTS -->

<script src="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/js/jquery.steps.js"></script>
<!--    <script src="<?php /*echo RELA_DIR . 'templates/' . CURRENT_SKIN; */?>/assets/js/jquery.rangerover.min.js"></script>
-->    <!-- Jquery-->
<script src="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/js/modernizr.js"></script>

<script src="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/js/bootstrap.min.js"></script>

<!-- Jquery-->
<script src="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/js/modernizr.js"></script>

<!-- Common script -->
<script src="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/js/common_scripts_min.js"></script>
<!-- Wizard script -->
<script src="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/js/registration_wizard_func.js"></script>
<!-- Menu script -->
<script src="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/js/velocity.min.js"></script>
<script src="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/js/main.js"></script>
<!-- Theme script -->
<script src="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/js/functions.js"></script>

</body>
</html>