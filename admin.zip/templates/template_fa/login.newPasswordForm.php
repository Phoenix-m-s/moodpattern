
<style>
    .card-header{
        border-bottom: none !important;
    }
</style>
<script language="javascript">
    if( navigator.userAgent.match(/Android/i)
        || navigator.userAgent.match(/webOS/i)
        || navigator.userAgent.match(/iPhone/i)
        || navigator.userAgent.match(/iPad/i)
        || navigator.userAgent.match(/iPod/i)
        || navigator.userAgent.match(/BlackBerry/i)
        || navigator.userAgent.match(/Windows Phone/i)
    ){
        //document.getElementById("alert-device").style.display = "block";
        //$("#alert-device").css("display", "block");
        alert('در این نسخه از نرم افزار، برای نمایش و کاربری مناسب تر لطفا از کامپیوتر شخصی یا لپ تاپ استفاده نمایید.');
    }else{
        //$("#alert-device").css("display", "none");
    }
</script>
<main>
    <div id="alert-device" class="alert alert-warning alert-dismissible fade show" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <strong>توجه!</strong> در این نسخه از نرم افزار، برای نمایش و کاربری مناسب تر لطفا از کامپیوتر شخصی یا لپ تاپ استفاده نمایید.
    </div>
    <div id="form_container">
        <div class="row">
            <div class="col-lg-5">
                <div id="left_formlogin">
                    <figure class="mt-3"><img src="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/img/logo.png" alt=""></figure>
                    <hr>
                    <p>ماموریت گراف های حسی از اینجا آغاز می شود: انجام فعل زندگی با هماهنگی و بدون آزار</p>
                    <hr>
                    <p class="text-white text-justify">
                        فهم و پذيرش بهتر ديگران، همان كسانى كه نمى توانيم بفهميم شان
                    </p>
                    <hr>
                    <p class="text-white text-justify">
                        پذيرش و درك خويش، آنجا كه نمى توانيم همان كسى باشيم كه مى خواهيم
                    </p>
                    <a href="#0" id="more_info" data-toggle="modal" data-target="#more-info"><i class="pe-7s-info"></i></a>

                </div>


            </div>
            <div class="col-lg-7">

                <div id="wizard_container">
                    <div id="top-wizard">
                        <div id="progressbar"></div>
                    </div>

                    <!-- /top-wizard -->
                    <form name="login" id="login" role="form" data-validate="form" class="form-horizontal" autocomplete="off" novalidate="novalidate" method="post">
                        <!-- Leave for security protection, read docs for details -->
                        <div id="middle-wizard">
                            <div class="card">
                                <div class="card-header">فراموش کردن رمز عبور</div>
                                <div class="card-body">
                                    <div class="col-xs-12 col-sm-12 col-12">
                                        <div class="login-edit">
                                            <p class="msgError"><?php echo $list['msg']; ?></p>
                                            <form action="/login/newPassword" method="post" name="form1" id="form1" role="form" novalidate="novalidate" data-toggle="validator">

                                                <div class="form-group errorHandler-login errorHandler eror has-feedback mt">
                                                    <input name="password" id="password" lang="fa" type="password" class=" form-control center-block noPadding" required data-error="رمز عبور جدید را وارد نمایید" placeholder="رمز عبور" autofocus">
                                                </div>
                                                <div class="form-group errorHandler-login errorHandler eror has-feedback mt">
                                                    <input name="re_password" id="confirm-password" lang="fa" type="password" class=" form-control center-block noPadding" required data-error="رمز عبور را دوباره وارد نمایید" placeholder="تکرار رمز عبور" autofocus">
                                                </div>
                                                <input name="company_id" type="hidden" value="<?php echo $list['company_id']; ?>">
                                                <input name="token" type="hidden" value="<?php echo $list['token']; ?>">
                                                <button type="submit" class="btn btn-default btn-primary btn-block">                            تایید</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <!-- /middle-wizard -->
                            </div>
                    </form>
                </div>
                <input type="hidden" name="action" value="login">
                <!-- /bottom-wizard -->
                </form>
            </div>
            <!-- /Wizard container -->
        </div>
    </div><!-- /Row -->
    </div><!-- /Form_container -->
</main>
