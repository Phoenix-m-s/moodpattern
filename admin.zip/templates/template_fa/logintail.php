
</section>

<!-- footer of website -->
<footer id="home" class="clearfix">
    <p dir="ltr">© 2019</p>
    <ul>
        <li><a href="#0" class="animated_link"><i class="fa fa-home"></i>صفحه اصلی</a></li>
        <li><a href="#0" class="animated_link"><i class="fa fa-phone-square"></i>تماس با ما </a></li>
    </ul>
</footer>
<!-- end footer-->


<!-- SCRIPTS -->
<!-- Jquery-->
<script src="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/js/jquery-3.2.1.min.js"></script>
<!-- Common script -->
<!-- Wizard script -->
<!-- Menu script -->


<!-- Theme script -->
<script src="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/js/functions.js"></script>


</body>
</html>