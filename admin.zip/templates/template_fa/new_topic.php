<style>
    #left_form p{
        font-size: 14px !important;
    }
    .faqHeader {
        font-size: 16px;
        margin: 5px;
    }
    .panel-title{
        font-size: 12px !important;
    }
    .panel-heading [data-toggle="collapse"]:after {
        font-family: 'Glyphicons Halflings';
        content: "\e072"; /* "play" icon */
        float: left;
        color: #F58723;
        font-size: 11px;
        line-height: 22px;
        /* rotate "play" icon from > (right arrow) to down arrow */
        -webkit-transform: rotate(-90deg);
        -moz-transform: rotate(-90deg);
        -ms-transform: rotate(-90deg);
        -o-transform: rotate(-90deg);
        transform: rotate(-90deg);
    }

    .panel-heading [data-toggle="collapse"].collapsed:after {
        /* rotate "play" icon from > (right arrow) to ^ (up arrow) */
        -webkit-transform: rotate(90deg);
        -moz-transform: rotate(90deg);
        -ms-transform: rotate(90deg);
        -o-transform: rotate(90deg);
        transform: rotate(90deg);
        color: #454444;
    }
    .funkyradio div {
        clear: both;
        overflow: hidden;
    }

    .funkyradio label {
        width: 100%;
        border-radius: 3px;
        font-weight: bold;
        font-size: 12px;
    }

    .funkyradio input[type="radio"]:empty,
    .funkyradio input[type="checkbox"]:empty {
        display: none;
    }

    .funkyradio input[type="radio"]:empty ~ label,
    .funkyradio input[type="checkbox"]:empty ~ label {
        position: relative;
        line-height: 1.2em;
        text-indent: 3.25em;
        cursor: pointer;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }

    .funkyradio input[type="radio"]:empty ~ label:before,
    .funkyradio input[type="checkbox"]:empty ~ label:before {
        position: absolute;
        display: block;
        top: 0;
        bottom: 0;
        right: 0;
        content: '';
        width: 2.5em;
        background: #D1D3D4;
        border-radius: 3px 0 0 3px;
    }

    .funkyradio input[type="radio"]:hover:not(:checked) ~ label,
    .funkyradio input[type="checkbox"]:hover:not(:checked) ~ label {
        color: #888;
    }

    .funkyradio input[type="radio"]:hover:not(:checked) ~ label:before,
    .funkyradio input[type="checkbox"]:hover:not(:checked) ~ label:before {
        content: '\2714';
        text-indent: .9em;
        color: #C2C2C2;
    }

    .funkyradio input[type="radio"]:checked ~ label,
    .funkyradio input[type="checkbox"]:checked ~ label {
        color: #777;
    }

    .funkyradio input[type="radio"]:checked ~ label:before,
    .funkyradio input[type="checkbox"]:checked ~ label:before {
        content: '\2714';
        text-indent: .9em;
        color: #333;
        background-color: #ccc;
    }

    .funkyradio input[type="radio"]:focus ~ label:before,
    .funkyradio input[type="checkbox"]:focus ~ label:before {
        box-shadow: 0 0 0 3px #999;
    }

    .funkyradio-default input[type="radio"]:checked ~ label:before,
    .funkyradio-default input[type="checkbox"]:checked ~ label:before {
        color: #333;
        background-color: #ccc;
    }

    .funkyradio-primary input[type="radio"]:checked ~ label:before,
    .funkyradio-primary input[type="checkbox"]:checked ~ label:before {
        color: #fff;
        background-color: #337ab7;
    }

    .funkyradio-success input[type="radio"]:checked ~ label:before,
    .funkyradio-success input[type="checkbox"]:checked ~ label:before {
        color: #fff;
        background-color: #5cb85c;
    }

    .funkyradio-danger input[type="radio"]:checked ~ label:before,
    .funkyradio-danger input[type="checkbox"]:checked ~ label:before {
        color: #fff;
        background-color: #d9534f;
    }

    .funkyradio-warning input[type="radio"]:checked ~ label:before,
    .funkyradio-warning input[type="checkbox"]:checked ~ label:before {
        color: #fff;
        background-color: #f0ad4e;
    }

    .funkyradio-info input[type="radio"]:checked ~ label:before,
    .funkyradio-info input[type="checkbox"]:checked ~ label:before {
        color: #fff;
        background-color: #5bc0de;
    }

</style>
<main xmlns="http://www.w3.org/1999/html">
    <div id="form_container">
        <div class="row">
            <div class="col-lg-4">
                <div id="left_form" style="height: 100%;">
                    <figure><img class="text-right" src="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/img/logo.png"  alt="گراف حسی"></figure>
                    <hr>
                    <p style="padding-top: 5px;font-weight: 700">
                        گراف حسی
                    </p>
                    <p style="padding-bottom: 20px;font-weight: 700;font-size: 14px;">
                        تحلیل آنچه که می خواهیم و نمی توانیم
                    </p>
                    <hr>
                    <p  style="padding-top: 5px;font-weight: 700;font-size: 14pt">
                        ماموریت گراف های حسی از اینجا آغاز می شود:
                    </p>
                    <p>
                        انجام فعل زندگی با هماهنگی و بدون آزار
                    </p>
                    <hr>
                        <a href="<?php echo RELA_DIR;?>topic/?action=help" class="text-white">
                            <figure style="padding-bottom: 15px;padding-top: 15px;"><img class="text-right" src="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/img/leader1.png" width="250px" height="250px" alt="گراف حسی"></figure>
                        </a>

                    <h5 class="text-white" style="padding-top: 10px;">ماموریت گراف های حسی
                    </h5>
                    <hr>
                    <p class="text-white text-justify">
                        چیزی را درست می دانم ( حفظ یا ترک یک فعالیت یا رابطه).
                    </p>
                    <p class="text-white text-justify">
                        بسیار خوب اما آیا قادر به انجام آن هم هستم یا هست؟
                    </p>
                    <p class="text-white text-justify">
                        و اگر بله، به چه قیمتی برای من (و او) تمام می شود؟
                    </p>
                    <p class="text-white text-justify">
                        پاسخ این پرسش یعنی کشف درجه هماهنگی حسی.
                    </p>

                </div>
            </div>
            <div class="col-lg-8">

                <div id="wizard_container">
                    <div id="top-wizard">
                        <div id="progressbar"></div>
                    </div>
                    <!-- /top-wizard -->
                    <form name="topic" id="topic" role="form" data-validate="form" class="form-horizontal" autocomplete="off" novalidate="novalidate" method="post">

                        <!-- Leave for security protection, read docs for details -->
                        <div id="middle-wizard">
                            <div class="col-md-12 mb-4">
                                <div class="text-center">
                                    <label for="title">
                                        <i class="fa fa-edit"></i> دوست من، گراف حسی کیفیت رابطه تو را با هر چیزی تحلیل می کند، حالا به من بگو چه کمکی می خوای و برای چه رابطه ای می خوای گراف بکشی:
                                    </label>
                                </div>
                            </div>
                            <div class="step">

                                <!-- /row -->
                                <div class="row"  style="border: 1px solid #8cb6b4; ">

                                    <div class="col-md-12">
                                        <div class="panel-group" id="accordion">
                                           
                                            <!--section1-->
                                            <div class="panel panel-default mt-5">
                                                 <!--tilte-->
                                                <div class="faqHeader">
    
                                                    <div class="funkyradio">
                                                        <div class="funkyradio-success">
                                                            <input type="radio" name="topic_type" id="radio1" value="1" />
                                                            <label for="radio1"> </label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false">ترسیم گراف برای نتیجه نهایی</a>
                                                    </h4>
                                                </div>
                                                <div id="collapseOne" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                                                    <div class="panel-body">
                                                        <strong>
                                                            موفقیت و شکست
                                                        </strong>

                                                        </br>
                                                        مشقلی برای رسیدن به هر هر هدفی یا انجام و یا عدم انجام هر کاری با دو چیز رابطه برقرار می کند:  </br>

                                                        ۱- نتیجه نهایی حاصل از انجام آن کار یا رسیدن به آن هدف</br>

                                                        ۲- رفتارهای روزانه ای که برای انجام کار یا رسیدن به هدف لازم است. </br>


                                                        عادت به کاری یعنی انجام آن کار بدون نیاز به صرف انرژی زیاد و بکار بردن اراده.
                                                        </br>
                                                        احساسی که مشقلی نسبت به نتیجه دارد یک چیز است و احساسی که نسبت به رفتارهای مورد نیاز برای رسیدن به نتیجه دارد چیز دیگری است.
                                                        </br>
                                                        کوروش

                                                    </div>
                                                </div>
                                            </div>
                                            <!--section1-->
                                            <div class="panel panel-default mt-5">
                                                 <!--tilte-->
                                                <div class="faqHeader">
    
                                                    <div class="funkyradio">
                                                        <div class="funkyradio-success">
                                                            <input type="radio" name="topic_type" id="radio2" value="2" />
                                                            <label for="radio2"> </label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseEight" aria-expanded="false">ترسیم گراف برای فعالیت ها یا رفتارهای روزانه</a>
                                                    </h4>
                                                </div>
                                                <div id="collapseEight" class="panel-collapse collapse" aria-expanded="false">
                                                    <div class="panel-body">
                                                        چرا کیفیت کلی رابطه مشقلی در دوران دوستی با دوران همسری فرق دارد؟
                                                        خوب اکنون می دانیم‌ که علت آن بسیار ساده است. رابطه روزانه مشقلی با نازگلی در دوران دوستی و دوران همسرداری اساسا دو چیز متفاوت است. این انها رابطه نهایی است که ثابت باقی مانده است. اما مسئله اینجاست که ایده ما از رابطه ، رابطه نهایی است. برای همین از تغییر کیفیت رابطه تعجب می کنیم.

                                                        احتمالا همه ما رابطه بسیار خوبی با نتیجه نهایی نقاشی، موسیقی، ورزش ، علم و ... داریم. یعنی گراف مثبتی نسبت به موفقیت نهایی در آنها داریم و د‌وست داریم که نقاش، موسیقیدان ، ورزشکار و دانشمند باشیم.
                                                        دست کم فکر نمی کنم مشقلی به غول چراغ جادو برای داشتن هیچ کدام از آنها نه بگوید.
                                                        </br>
                                                        اما آنچه که در دنیای واقعی این امکان را برای او  فراهم می کند نه غول چراغ جادو و نه اشتیاق او به داشتن این توانایی ها است بلکه  کیفیت مناسب «رابطه با رفتار های روزانه» این امور کلید صندوقچه گنج  است.
                                                        </br>
                                                        رابطه روزانه نشان می دهد مشقلی چقدر آدم مناسب و توانایی برای چنین کاری است.
                                                        این کار چه تاثیری روی او می گذارد. چه چیزهایی به روان او می بخشد و چه چیزهایی را از روان او می گیرد.
                                                        </br>
                                                        پیش از ترسیم « گراف رابطه روزانه» با هر موضوعی لازم است آیتم های روزانه این رویداد را بنو‌یسیم در ‌پیش ذهن داشته باشیم.
                                                        </br>
                                                        توجه داشته باشید که تمام پرسش ها ی گراف مربوط به احساس و افکار ما نسبت به این آیتم ها است نه نسبت به خود موضوع ( یا همان نتیجه نهایی)

                                                    </div>
                                                </div>
                                            </div>
                                           
                                          
                                       
                                            <div class="panel panel-default  mt-5">
                                              <!--tilte-->
                                                <div class="faqHeader">
    
                                                    <div class="funkyradio">
                                                        <div class="funkyradio-success">
                                                            <input type="radio" name="topic_type" id="radio3" value="3" />
                                                            <label for="radio3"> </label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--section1-->
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseEleven" aria-expanded="false">ترسیم گراف برای ترک عادت و یا ایجاد عادت جدید</a>
                                                    </h4>
                                                </div>
                                                <div id="collapseEleven" class="panel-collapse collapse" aria-expanded="false">
                                                    <div class="panel-body">
                                                        اگه گراف قراره که کیفیت «رابطه روزانه »تو رو با یک فعالیت، عادت یا هدف تحلیل کنه پس لازمه که آیتم های روزانه برنامه یا عادت یا حرکت به سمت هدفت رو مشخص کنی.
                                                        </br>
                                                        برنامه یعنی کار و فعالیتی که الان توش هستی و داری انجامش می دی.
                                                        </br>
                                                        فهرست این آیتم ها رو بنویس. و یادت باشه همه سوال های من درباره احساس و افکار تو نسبت به این رفتار ها است نه خود هدف یا برنامه ات.
                                                        </br>
                                                        نکته: اگه می خوای عادتی رو ترک کنی ( مثل پرخوری یا مصرف سیگار) یا عادت جدیدی رو ایجاد کنی در هر دو صورت بهتره آیتم های «انجام» این عادت را فهرست کنی.

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="panel panel-default mt-5 ">
                                                 <!--tilte-->
                                                <div class="faqHeader">
    
                                                    <div class="funkyradio">
                                                        <div class="funkyradio-success">
                                                            <input type="radio" name="topic_type" id="radio4" value="4" />
                                                            <label for="radio4"> </label>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false">ترسیم گراف رابطه انسانی</a>
                                                    </h4>
                                                </div>
                                                <!--section 1-->
                                                <div id="collapseFour" class="panel-collapse collapse" aria-expanded="false">
                                                    <div class="panel-body">
                                                        <p>رابطه ی میان آ و ب از خود آ و ب قوی تر است. چون بر خلاف تصور رایج، رابطه ی میان آن دو، خط ارتباطی میان آن دو نیست، بلکه جو و فضایی ست که آن دو در آن یکدیگر را تجربه می کنند. مثل هوایی که در آن نفس می کشیم. هر چقدر خردمند تر می شویم بیشتر در میابیم که محیط زیست از خود زیست کننده ها قوی تر و لاجرم نیازمند مراقبت است.</p>
                                                        <p>بهترین آدم ها در رابطه ی ، بد می شوند. چون رابطه از خود ارتباط گبرنده قوی تر است.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-4" style="border:1px solid #8cb6b4; ">
                                    <div class="col-md-12 mt-4">
                                        <div class="panel panel-default mb-5">
                                            <div class="panel-heading">
                                                <h4 class="panel-title">
                                                    <div class="form-group">
                                                        <input type="text" name="title" required class="form-control" placeholder="موضوع : ">
                                                    </div>
                                                    <div class="row" style="display:none;" id="type-class1" >
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <select class="form-control" id="topic_class_1" name="topic_class_1">
                                                                    <option value="">نوع فعالیت را انتخاب نمایید</option>
                                                                    <?php
                                                                    foreach($list['list']['topic_class'][1] as $k=>$v){
                                                                        echo '<option value="'.$v['id'].'">'.$v['title'].'</option>' ;

                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row" style="display:none;" id="type-class2">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <select class="form-control" id="topic_class_2" name="topic_class_2">
                                                                    <option value="">نوع رابطه را انتخاب نمایید</option>
                                                                    <?php
                                                                    foreach($list['list']['topic_class'][2] as $k=>$v){
                                                                        echo '<option value="'.$v['id'].'">'.$v['title'].'</option>' ;

                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>

                                                    </div>

                                                </h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                            <!-- /row -->

                            <div class="row">
                                <button type="submit" name="submit" class="mt-5 btn btn-info btn-block mb-2" ><i class="fa fa-hourglass-start"></i> شروع </button>
                            </div>


                        </div>

                </div>
                <input name="action" type="hidden" id="action" value="add">
                <!-- /middle-wizard -->


                <!-- /bottom-wizard -->
                </form>
            </div>
            <!-- /Wizard container -->
        </div>
    </div><!-- /Row -->
    </div><!-- /Form_container -->
    <script language="JavaScript">
        function displaytypeclass() {
            //alert('test');
            var ele = document.getElementsByName('topic_type');
            var divclass1 = document.getElementById('type-class1') ;
            var divclass2 = document.getElementById('type-class2') ;
            for(i = 0; i < ele.length; i++) {
                //ele[i].addEventListener("click", displaytypeclass);
                ele[i].onclick = displaytypeclass ;
                ele[i].className = "iradio_square-grey" ;
                if(ele[i].checked){
                    //alert(ele[i].value) ;
                    if(ele[i].value == 1 || ele[i].value == 3 || ele[i].value == 4){
                        divclass1.style.display = 'block' ;
                        divclass2.style.display = 'none' ;
                    }else if(ele[i].value == 2){
                        divclass2.style.display = 'block' ;
                        divclass1.style.display = 'none' ;
                    }
                }
            }
        }
        displaytypeclass();
        //ele.onclick = displaytypeclass ;
    </script>
</main>