
<!DOCTYPE html>
<html lang="fa-IR" prefix="og: http://ogp.me/ns#">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=1">
    <meta name="description" content="seemorgh - Register, Reservation, Questionare, Reviews form wizard">
    <meta name="author" content="Ansonika">
    <title>گراف حسی</title>

    <!-- Favicons-->
    <link rel="shortcut icon" href="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/img/icon.png" >

    <!-- GOOGLE WEB FONT -->
    <link href="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/css/farsi-font.css" rel="stylesheet">

    <!-- BASE CSS -->
    <link href="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/css/bootstrap4.min.css" rel="stylesheet">
    <link href="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/css/style.css" rel="stylesheet">
    <link href="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets//css/responsive.css" rel="stylesheet">
    <link href="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/css/menu.css" rel="stylesheet">
    <link href="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/css/animate.min.css" rel="stylesheet">
    <link href="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/css/icon_fonts/css/all_icons_min.css" rel="stylesheet">
    <link href="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/css/skins/square/grey.css" rel="stylesheet">
    <link href="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/css/font-awesome.min.css" rel="stylesheet">

    <link href="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/css/bootstrap-slider.min.css" rel="stylesheet">
    <script src="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/js/bootstrap-slider.min.js"></script>

    <!-- YOUR CUSTOM CSS -->
    <link href="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/css/custom.css" rel="stylesheet">


    <!-- Jquery-->
    <script src="<?php echo RELA_DIR . 'templates/' . CURRENT_SKIN; ?>/assets/js/modernizr.js"></script>
    <style>
         @media screen and (max-device-width:767px){
      
        .middle-wizard{
            padding:0 10px !important;
        }
        input.form-control, select.form-control, textarea.form-control{
             padding:0 !important;
            font-size:15px !important;
        }
            }
    </style>

</head>
<!-- <div class="overWhite"> -->
<body dir="rtl">
<div id="preloader">
    <div data-loader="circle-side"></div>
</div><!-- /Preload -->

<div id="loader_form">
    <div data-loader="circle-side-2"></div>
</div><!-- /loader_form -->


<!-- /end of header -->
<section class="container  mainContainer">
