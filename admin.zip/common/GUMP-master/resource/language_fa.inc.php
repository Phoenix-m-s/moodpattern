<?php
//index.php member page
define("INDEX_001", "خانه");
define("INDEX_002", "داشبورد سیستم تلفنی");
define("INDEX_003", "وضعیت سرور");
define("INDEX_004", "وضعیت سرور");
define("INDEX_005", "وضعیت سرور");
define("INDEX_006", "وضعیت سرور");
define("INDEX_007", "داشبورد کمپین");
define("INDEX_008", "اطلاعات نموداری");
define("INDEX_009", "اطلاعات نموداری");
