<?php

class looeicConfig{


    public static function getConfig() {

        $config['export_type']='api';
        return $config;
    }

}
?>