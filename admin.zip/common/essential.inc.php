<?php
/**
 * Created by PhpStorm.
 * User: Netplorer
 * Date: 7/2/14
 * Time: 4:47 PM
 */

include_once(ROOT_DIR . "common/db.inc.php");
include_once(ROOT_DIR . "common/init.inc.php");
include_once(ROOT_DIR . "common/func.inc.php");
include_once(ROOT_DIR . "common/validator.php");
include_once(ROOT_DIR . "model/db.inc.class.php");

