<?php
$looic_export['type']='old';
