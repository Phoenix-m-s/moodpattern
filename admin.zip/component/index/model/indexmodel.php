<?php
class indexmodel extends looeic
{
    protected $TABLE_NAME = 'users';
}