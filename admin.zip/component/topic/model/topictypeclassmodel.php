<?php
/**
 * Created by PhpStorm.
 * User: fheydarlou
 * Date: 9/27/2019
 * Time: 4:24 AM
 */
class topictypeclassmodel extends looeic
{
    protected $TABLE_NAME = 'topic_type_class';
   /* protected $rules = array(
        '' => 'required*' . 'please fill in the ivr_name'
    );*/
}