<?php
/**
 * Created by PhpStorm.
 * User: fheydarlou
 * Date: 9/27/2019
 * Time: 4:24 AM
 */
class topicmodel extends looeic
{
    protected $TABLE_NAME = 'user_topics';
   /* protected $rules = array(
        '' => 'required*' . 'please fill in the ivr_name'
    );*/
}