<?php
/**
 * Created by PhpStorm.
 * User: malek
 * Date: 2/20/2016
 * Time: 4:24 AM
 */
class questionmodel extends looeic
{
    protected $TABLE_NAME = 'topic_sensory_sensors_score';
//    protected $rules = array(
//        '' => 'required*' . 'please fill in the ivr_name'
//    );
}