<?php
/**
 * Created by PhpStorm.
 * User: ftmh
 * Date: 9/27/2019
 * Time: 5:24 PM
 */
class sensormodel extends looeic
{
    protected $TABLE_NAME = 'sensory_sensors';
//    protected $rules = array(
//        '' => 'required*' . 'please fill in the ivr_name'
//    );
}