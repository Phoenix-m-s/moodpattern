<?php
/**
 * Created by PhpStorm.
 * User: ftmh
 * Date: 9/27/2019
 * Time: 5:25 PM
 */
class wordscoremodel extends looeic
{
    protected $TABLE_NAME = 'topic_sensory_sensors_score';
//    protected $rules = array(
//        '' => 'required*' . 'please fill in the ivr_name'
//    );
}