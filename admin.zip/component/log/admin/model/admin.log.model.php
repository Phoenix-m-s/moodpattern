<?php

include_once ROOT_DIR . '/common/validators.php';

class adminLogModel extends looeic
{
    protected $TABLE_NAME = "log";
}
