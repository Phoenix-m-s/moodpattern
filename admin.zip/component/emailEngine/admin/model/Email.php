<?php

class Email extends looeic
{
    protected $TABLE_NAME = 'email';
}