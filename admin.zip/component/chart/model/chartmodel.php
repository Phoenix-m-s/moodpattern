<?php
/**
 * Created by PhpStorm.
 * User: ftmh
 * Date: 9/27/2019
 * Time: 5:25 PM
 */
class chartmodel extends looeic
{
    protected $TABLE_NAME = 'sensor_graph';
//    protected $rules = array(
//        '' => 'required*' . 'please fill in the ivr_name'
//    );
}