<?php
/**
 * Created by PhpStorm.
 * User: malek
 * Date: 2/20/2016
 * Time: 4:24 AM
 */
class provincemodel extends looeic
{
    protected $TABLE_NAME = 'province';
   /* protected $rules = array(
        '' => 'required*' . 'please fill in the ivr_name'
    );*/
}