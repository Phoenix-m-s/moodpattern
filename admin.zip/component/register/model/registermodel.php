<?php
/**
 * Created by PhpStorm.
 * User: malek
 * Date: 2/20/2016
 * Time: 4:24 AM
 */
class registermodel extends looeic
{
    protected $TABLE_NAME = 'users';
   /* protected $rules = array(
        '' => 'required*' . 'please fill in the ivr_name'
    );*/
}