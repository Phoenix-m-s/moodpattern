<?php

echo '<pre/>';

print_r($_SERVER);

/**
 * Created by PhpStorm.
 * User: hhh
 * Date: 5/28/2018
 * Time: 3:44 PM
 */
?>