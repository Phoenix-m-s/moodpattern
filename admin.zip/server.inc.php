<?php
error_reporting(E_ALL);
ini_set('error_display',0);
error_reporting(0);

session_start();
define("DB_TYPE","mysqli");
define("DB_HOST","localhost");
define("DB_USER","moodpatt_sensory_graph");
define("DB_PASSWORD","2019sensory_graph1398");

define("DB_DATABASE","moodpatt_sensory_graph");
define("ROOT_DIR",dirname(__FILE__) ."/");

define("SUB_FOLDER","");

define("RELA_DIR","http://".$_SERVER['HTTP_HOST']."/".SUB_FOLDER."");