<?php
$country = array('FR', 'MA');
?>