<?php
// session_start();
include"../antibot.php";
include"../func.php";
?>
